#!/bin/bash
_key=$(curl -s -X RAW http://keyserver/gracenote)
if [ "$_key" == "" ]
then
    echo err keyserver
    exit 1
fi

_countrys=("AUT|6886" "CHE|3303" "DEU|14050")

declare -A _callids
declare -A _ids

# get all channel providers
#http://data.tmsapi.com/v1.1/lineups?country=&postalCode=&api_key=

for _country in ${_countrys[@]}
do
break
    _postal=${_country#*|}
    _country=${_country%%|*}
    echo build country: $_country postal: $_postal
    while read -u4 -r _lineup
    do
        if [ ! -e $_country.$_lineup.lineup ]
        then
            _data=$(curl -sf "http://data.tmsapi.com/v1.1/lineups/AUT-1000414-DEFAULT/channels?imageSize=Sm&enhancedCallSign=false&api_key=$_key")
            if [ $? -eq 0 ]
            then
                echo -e "\tsuccess downloaded lineups for $_lineup"
                echo "$_data" > $_country.$_lineup.lineup
            else
                echo -e "\tfailed lineup $_lineup"
            fi
        fi
    done 4< <(curl -sf "http://data.tmsapi.com/v1.1/lineups?country=$_country&postalCode=$_postal&api_key=$_key"|jq -r '.[]|.lineupId')
done

_count=0

while read -u4 _lineup
do
break
    echo check lineup $_lineup
    while read -u5 _channel_data
    do
        #echo $_channel_data
        [[ "$_channel_data" =~ ^(.*)\|(.*)\|(.*)$ ]]
        _id=${BASH_REMATCH[1]}
        _call=${BASH_REMATCH[2]}
        _cover=${BASH_REMATCH[3]}
        #echo $_id
        #echo $_name
        #echo $_cover
        if [ "${_callids[$_call]}" == "" ] && [ "${_ids[$_id]}" == "" ]
        then
            _callids[$_call]=$_call
            _ids[$_id]=$_id
            if [ ! -e $_call.$_id.info ]
            then
                _data=$(curl -sf "http://data.tmsapi.com/v1.1/stations/$_id?imageSize=Sm&api_key=$_key" )
                if [ $? -ne 0 ]
                then
                    continue
                fi
                echo "$_data" > $_call.$_id.info
                echo -e "\t$_call $_id info downloaded"
                _count=$((_count+1));if [ $_count -gt 30 ]; then echo wait;sleep 30;_count=0;fi
            fi
        else
            :
            #echo -e "\tduplicate $_call $_id"
        fi
    done 5< <(cat $_lineup|jq -r '.[]|.stationId+"|"+.callSign+"|"+.preferredImage.uri')
done 4< <(ls *.lineup)


echo -n '{"channellist": [' > gracenote.json
_in=0
while read -u4 _info
do
    if [ $_in -eq 1 ]; then echo -n "," >> gracenote.json; fi
    _data=$(cat "$_info"|jq -r '.[]|.stationId+"|"+.name+"|"+.bcastLangs[0]+"|"+.preferredImage.uri')
    [[ "$_data" =~ ^(.*)\|(.*)\|(.*)\|(.*)$ ]]
    _id=${BASH_REMATCH[1]}
    _name=${BASH_REMATCH[2]}
    _lang=${BASH_REMATCH[3]}
    _img=${BASH_REMATCH[4]}
    echo -n '{"contentId":"'"$_id"'","name": "'"$_name"'","lang": "'"${_lang^^}"'","pictures": [{"href": "'"$_img"'"}]}' >> gracenote.json
    _in=1
done 4< <(ls *.info)

echo -n ']}' >> gracenote.json